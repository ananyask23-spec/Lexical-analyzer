

/*Name :Ananya S k
Description : Lexical Analyser
Date :13/11/2025*/

#include<stdio.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>
    //storing 32 keywords in 2-d array
    //each keyword can be length up to 9 characters and one column for null 
    char keywords[32][10]={"auto","break","case","char","const","continue","default","do",
        "double","else","enum","extern","float","for","goto","if",
        "int","long","register","return","short","signed","sizeof","static",
        "struct","switch","typedef","union","unsigned","void","volatile","while"};

    //operators of maximum length 7
   char operators[38][7] ={
    "+", "-", "*", "/", "%",
    "==", "!=", ">", "<", ">=", "<=",
    "&&", "||", "!",
    "&", "|", "^", "~", "<<", ">>",
    "=", "+=", "-=", "*=", "/=", "%=", "<<=", ">>=", "&=", "^=", "|=",
    "++", "--",
    "?", ":", "sizeof","->",","};

    //symbols of maximum lenth is 2
    /*char symbols[2][2]={ ";",   "." };*/
    //symbols of maximum lenth is 2 
    
    int line_count=1;
    
    //function to comapare operators which is already stored in 2-D array
    int isoperator(char *buffer)
    {
      //loop to compare all operators
      for(int i=0;i<38;i++)
      {
        if(strcmp(buffer, operators[i])==0)
        {
          //if present return 1
          return 1;
        }

      }
      return 0;
    }
    //function to check operators
    void isstore_operator(FILE *fp, int ch)
    {
       char buffer[7];
       int i=0;
       //first store first character in an buffer
       buffer[i++]=ch;
       buffer[i]='\0';

       //read second character
       ch=fgetc(fp);
       if(ch!=EOF)
       {
        //again store it in buffer
        buffer[i++]=ch;
        buffer[i]='\0';

        //check if both character makes an operator
        if(!isoperator(buffer))
        {
          //if not remove one
          buffer[--i]='\0';
          ungetc(ch, fp);
        }
       }
    //if it is operator print it
    if(isoperator(buffer))
    {
      printf("Operator : %s\n", buffer);
    }
  }

   //function to comapare keyword which is already stored in 2-D array
    int iskeyword(char *keyword_buffer)
    {
      //loop to check 32 keywords
      for(int j=0;j<32;j++)
    {
    if(strcmp(keyword_buffer, keywords[j])==0)
    {
      //if present return 1
      return 1;
    }
    }
  return 0;
   }
  int main(int argc, char*argv[])
   {
    if(argc<2)
    {
        printf("error: pass other file");
        return 1;
    }
    
    FILE *fp;
    fp = fopen(argv[1], "r");
    if(fp == NULL) 
    {
        printf("Unable to open the file\n");
        return 1;
    }

    int ch;
    char keyword_buffer[50];
    int parenth_count=0;
    int flower_braces_count=0;
    int square_count=0;
    int line_count=1;


    while((ch = fgetc(fp)) != EOF) 
    {
         

        if(ch=='\n')
        {
            // NEW LOGIC: check if any opening bracket is left open on this line 
            if(parenth_count>0) {
                printf("Error: line number :%d missing closing )\n", line_count);
                exit(0);
            }
            if(square_count>0) {
                printf("Error: line number :%d missing closing ]\n", line_count);
                exit(0);
            }
            // for '{' we don't check at newline, only at EOF (because blocks contain multiple lines)
            line_count++;
            continue;
        }

        // Skip preprocessor directives
        if(ch == '#') 
        {
            while(ch != '\n' && ch != EOF)
                ch = fgetc(fp);
                line_count++;
            continue;
        }

        // Skip comments
        if(ch == '/') {
            int next = fgetc(fp);
            if(next == '/') { // single-line comment
                while(ch != '\n' && ch != EOF)
                    ch = fgetc(fp);
                    line_count++;
                continue;
            } 
            else if(next == '*') { // multi-line comment
                while(1) 
                {
                    ch = fgetc(fp);
                    if(ch == EOF) break;
                    if(ch == '*') {
                        next = fgetc(fp);
                        if(next == '/') 
                        break;
                        else ungetc(next, fp);
                    }
                }
                continue;
            } 
            else { // '/' operator
                ungetc(next, fp);
                isstore_operator(fp, '/');
                continue;
            }
        }
        

        // Identifier or keyword
        if(isalpha(ch) || ch == '_') {
            int i = 0;
            while(isalnum(ch) || ch == '_') {
                keyword_buffer[i++] = ch;
                ch = fgetc(fp);
            }
            keyword_buffer[i] = '\0';

            if(iskeyword(keyword_buffer))
                printf("Keyword : %s\n", keyword_buffer);
            else
                printf("Identifier : %s\n", keyword_buffer);

            if(ch != EOF)
                ungetc(ch, fp);
            continue;
        }
          // Braces/parentheses/square brackets
        if(ch=='{') {
            printf("Symbol : %c\n", ch);
            flower_braces_count++;
            continue;
        }
        if(ch=='(') {
            printf("Symbol : %c\n", ch);
            parenth_count++;
            continue;
        }
        if(ch=='[') {
            printf("Symbol : %c\n", ch);
            square_count++;
            continue;
        }
        if(ch=='}') {
            if(flower_braces_count>0) {
                printf("Symbol : %c\n", ch);
                flower_braces_count--;
                continue;
            } else {
                printf("Error: unexpected }\n");
                exit(0);
            }
        }
        if(ch==')') {
            if(parenth_count>0) {
                printf("Symbol : %c\n", ch);
                parenth_count--;
                continue;
            } else {
                printf("Error: line number :%d unexpected )\n", line_count);
                exit(0);
            }
        }
        if(ch==']') {
            if(square_count>0) {
                printf("Symbol : %c\n", ch);
                square_count--;
                continue;
            } else {
                printf("Error: line number :%d unexpected ]\n", line_count);
                exit(0);
            }
        }

        // Symbol
        if(ch==';') 
        {
            printf("Symbol : %c\n", ch);
            continue;
        }

        // Operator
        if(strchr("=+-*/%<>!&|^~?:,", ch)) {
            isstore_operator(fp, ch);
            continue;
        }

        // Numeric constants
        if(isdigit(ch)) {
            int i = 0;
            char buffer[50];
            buffer[i++] = ch;
            ch = fgetc(fp);

            // HEXADECIMAL
            if(buffer[0] == '0' && (ch == 'x' || ch == 'X')) {
                buffer[i++] = ch;
                ch = fgetc(fp);
                if(!isxdigit(ch)) {
                    printf("Error: line number :%d Invalid hexadecimal constant %c\n", line_count, ch);
                    exit(0);
                }
                while(isxdigit(ch)) {
                    buffer[i++] = ch;
                    ch = fgetc(fp);
                }
                if(isalpha(ch)) {
                    printf("Error: line number :%d Invalid suffix %c on integer constant\n",line_count, ch);
                    exit(0);
                }
                if(ch != EOF) 
                ungetc(ch, fp);
                buffer[i] = '\0';
                printf("Numeric constant (hex): %s\n", buffer);
                continue;
            }

            // BINARY
            else if(buffer[0] == '0' && (ch == 'b' || ch == 'B')) {
                buffer[i++] = ch;
                ch = fgetc(fp);
                if(ch != '0' && ch != '1') {
                    printf("Error: line number :%d Invalid binary constant %s\n",line_count, buffer);
                    exit(0);
                }
                while(ch == '0' || ch == '1') {
                    buffer[i++] = ch;
                    ch = fgetc(fp);
                }
                if(isdigit(ch)) {
                    printf("Error: line number :%d Invalid digit %c on binary constant\n",line_count, ch);
                    exit(0);
                }
                if(ch != EOF) ungetc(ch, fp);
                buffer[i] = '\0';
                printf("Numeric constant (binary): %s\n", buffer);
                continue;
            }

            // OCTAL
            else if(buffer[0] == '0' && isdigit(ch)) {
                while(isdigit(ch)) {
                    if(ch >= '8') {
                        printf("Error: line number :%d Invalid octal constant %c\n", line_count, ch);
                        exit(0);
                    }
                    buffer[i++] = ch;
                    ch = fgetc(fp);
                }
                if(isalpha(ch)) {
                    printf("Error: line number :%d Invalid suffix %c on integer constant\n",line_count, ch);
                    exit(0);
                }
                if(ch != EOF) ungetc(ch, fp);
                buffer[i] = '\0';
                printf("Numeric constant (octal): %s\n", buffer);
                continue;
            }

            // DECIMAL / FLOAT
            else {
                int float_dot = 0;
                while(isdigit(ch) || ch == '.') {
                    if(ch == '.') {
                        if(float_dot) break;
                        float_dot = 1;
                    }
                    buffer[i++] = ch;
                    ch = fgetc(fp);
                }
                if(ch == 'f' || ch == 'F') {
                    buffer[i++] = ch;
                    ch = fgetc(fp);
                }
                if(isalpha(ch)) {
                    buffer[i++] = ch;
                    buffer[i] = '\0';
                    printf("Error: line number :%d Identifier cannot start with digit: %s\n",line_count, buffer);
                    exit(0);
                }
                if(ch != EOF) ungetc(ch, fp);
                buffer[i] = '\0';
                if(float_dot)
                    printf("Numeric constant (float): %s\n", buffer);
                else
                    printf("Numeric constant (integer): %s\n", buffer);
                continue;
            }
        }

        // Character constant
        if(ch == '\'') 
        {
            int value = fgetc(fp);
            if(value == EOF || value == '\n')
             {
                printf("Error: line number :%d Unterminated character constant\n", line_count);
                exit(0);
            }
            if(value=='\\')
            {
            int esc=fgetc(fp);
            if (esc == EOF || esc == '\n') 
            {
            printf("Error: line %d Unterminated escape sequence\n", line_count);
            exit(0);
            }
switch(esc)
{
    case 'n':
        value = '\n';
        break;

    case 't':
        value = '\t';
        break;

    case '0':
        value = '\0';
        break;

    case '\\': // one backslash
        value = '\\';
        break;

    case '\'': // single quote
        value = '\'';
        break;

    case '\"': // double quote
        value = '\"';
        break;

    default:
        printf("Error: line %d Invalid escape sequence \\%c\n", line_count, esc);
        exit(0);
}
    
}
            int next = fgetc(fp);
            if(next != '\'') 
            {
                printf("Error: line number :%d  Missing terminating ' character\n", line_count);
                exit(0);
            }
        
            printf("Character constant: ");
if (value == '\n')
    printf("\\n\n");       // show newline as \n
else if (value == '\t')
    printf("\\t\n");       // show tab as \t
else if (value == '\0')
    printf("\\0\n");       // show null as \0
else if (value == '\\')
    printf("\\\\\n");      // show backslash as 
else if (value == '\'')
    printf("\\'\n");       // show single quote as \'
else if (value == '\"')
    printf("\\\"\n");      
else
    printf("%c\n", value); // print normal visible character
continue;
}
        

        // String literal
        // String literal
if (ch == '"') {
    int i = 0;
    char buffer[200];
    ch = fgetc(fp);

    while (ch != '"' && ch != EOF && ch != '\n') {
        if (ch == '\\') {  // escape sequence inside string
            buffer[i++] = ch;      // store '\'
            ch = fgetc(fp);
            if (ch == EOF || ch == '\n') {
                printf("Error: line number :%d Unterminated escape sequence in string\n", line_count);
                exit(0);
            }
            buffer[i++] = ch;      // store escaped char (like n, t, ", \)
        } else {
            buffer[i++] = ch;
        }
        ch = fgetc(fp);
    }

    if (ch != '"') {
        printf("Error: line number :%d Missing terminating \" character\n", line_count);
        exit(0);
    }

    buffer[i] = '\0';
    printf("String literal: %s\n", buffer);
    continue;
}
    }
    if(parenth_count!=0)
    {
     printf("Error: line number :%d  missing closing )\n", line_count);
    exit(0);
    }
    if(square_count!=0)
    {
     printf("Error: line number :%d missing closing ]\n", line_count);
    exit(0);
    }
    if(flower_braces_count!=0)
    {
      printf("Error: missing closing }\n");
    exit(0);
    }

    fclose(fp);
    return 0;
}
