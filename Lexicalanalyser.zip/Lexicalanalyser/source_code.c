#include<stdio.h>
int main()
  {
    int num1=0;
    int num2;
    scanf("%d", &num2);
    int arr[5];
    for(int i=0;i<5;i++)
    {
      printf("hii");
    }
    return 0;
  }